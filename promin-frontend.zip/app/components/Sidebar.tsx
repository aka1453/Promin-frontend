"use client";

import Link from "next/link";
import { supabase } from "../lib/supabaseClient";
import { useEffect, useState } from "react";
import AddProjectButton from "./AddProjectButton";
import { useRouter, usePathname } from "next/navigation";
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
} from "@dnd-kit/core";
import {
  SortableContext,
  verticalListSortingStrategy,
  useSortable,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { reorderProjects } from "../lib/reorderProjects";
import { useProjects } from "../context/ProjectsContext";

// Define the shape of a project
type Project = {
  id: number;
  name: string;
};
function SortableProjectItem({
  project,
  active,
}: {
  project: { id: number; name: string };
  active: boolean;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } =
    useSortable({ id: project.id });

  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.95 : 1,
    zIndex: isDragging ? 50 : "auto",
  };

  return (
    <div
  ref={setNodeRef}
  style={style}
  className={
    "flex items-center gap-3 px-4 py-2 rounded-lg text-base transition duration-150 select-none " +
    (active
      ? "bg-blue-50 text-blue-800 font-medium"
      : "text-gray-900 hover:bg-gray-100") +
    (isDragging ? " bg-white shadow-md" : "")
  }
>
  {/* DRAG HANDLE */}
  <span
    {...attributes}
    {...listeners}
    onClick={(e) => {
      e.preventDefault();
      e.stopPropagation();
    }}
    className="
      text-gray-400
      cursor-grab
      active:cursor-grabbing
      text-lg
      leading-none
      opacity-70
      hover:opacity-100
    "
    title="Drag to reorder"
  >
    ☰
  </span>

  {/* PROJECT LINK */}
  <Link
    href={`/projects/${project.id}`}
    className="block flex-1 truncate"
  >
    {project.name || "Untitled Project"}
  </Link>
</div>

  );
}



export default function Sidebar() {
  const router = useRouter();
  const { projects, reloadProjects } = useProjects();

  // Optimistic order for sidebar (prevents snap-back while DB saves)
  const [optimisticOrder, setOptimisticOrder] = useState<number[] | null>(null);

  const activeProjects = projects.filter(
    (p: any) => p.deleted_at == null && p.status !== "archived"
  );


const archivedProjects = projects.filter(
  (p: any) => p.deleted_at == null && p.status === "archived"
);

const activeProjectsForRender = optimisticOrder
  ? optimisticOrder
      .map((id) => activeProjects.find((p: any) => p.id === id))
      .filter(Boolean)
  : activeProjects;

const deletedProjects = projects.filter(
  (p: any) => p.deleted_at != null
);

const [showArchived, setShowArchived] = useState(false);

useEffect(() => {
  // If the underlying projects list changes, drop optimistic order
  // so we don't render stale IDs.
  setOptimisticOrder(null);
}, [projects]);

  const sensors = useSensors(
  useSensor(PointerSensor, { activationConstraint: { distance: 5 } })
);

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push("/login");
  }

  const pathname = usePathname();
const activeProjectId = (() => {
  const m = pathname?.match(/^\/projects\/(\d+)/);
  return m ? Number(m[1]) : null;
})();

return (
  <aside className="fixed left-0 top-0 z-40 flex h-screen w-64 flex-col bg-white border-r border-gray-200">
    {/* BRAND */}
    <div className="px-6 py-6 border-b border-gray-200">
      <h1 className="text-2xl font-semibold text-gray-900">ProMin</h1>
    </div>

    {/* ADD PROJECT (FULL WIDTH) */}
    <div className="px-4 py-4">
      <div className="[&>button]:w-full [&>button]:px-4 [&>button]:py-3 [&>button]:rounded-xl [&>button]:font-semibold [&>button]:text-base [&>button]:bg-blue-700 [&>button]:text-white [&>button:hover]:bg-blue-800">
        <AddProjectButton
  onCreated={async () => {
    await reloadProjects();
  }}
/>

      </div>
    </div>

    {/* PROJECTS LIST */}
    <nav className="flex-1 overflow-y-auto px-4 py-2">
      <div className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-3">
        Projects
      </div>

      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragEnd={async (event) => {
  const { active, over } = event;
  if (activeProjects.length < 2) return;
  if (!over || active.id === over.id) return;

  const oldIndex = activeProjects.findIndex(
    (p: Project) => p.id === active.id
  );
  const newIndex = activeProjects.findIndex(
    (p: Project) => p.id === over.id
  );
  if (oldIndex === -1 || newIndex === -1) return;

  const reordered = [...activeProjects];
  const [moved] = reordered.splice(oldIndex, 1);
  reordered.splice(newIndex, 0, moved);

  // Optimistic UI: render new order immediately (prevents snap-back)
  setOptimisticOrder(reordered.map((p) => p.id));

  try {
    await reorderProjects(reordered.map((p) => p.id));
    await reloadProjects(); // converge to DB truth
  } finally {
    // Always clear optimistic state (even if DB fails)
    setOptimisticOrder(null);
  }
}}


      >
        <SortableContext
  items={activeProjectsForRender.map((p: any) => p.id)}
  strategy={verticalListSortingStrategy}
>


          <div className="flex flex-col gap-1">
  {activeProjectsForRender.map((p: any) => (
    <SortableProjectItem
      key={p.id}
      project={p}
      active={activeProjectId === p.id}
    />
  ))}
</div>

        </SortableContext>
      </DndContext>
      {/* ARCHIVED PROJECTS */}
{archivedProjects.length > 0 && (
  <div className="mt-4">
    <button
      onClick={() => setShowArchived(v => !v)}
      className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2 hover:text-gray-700"
    >
      Archived {showArchived ? "▾" : "▸"}
    </button>

    {showArchived && (
      <div className="flex flex-col gap-1 opacity-70">
        {archivedProjects.map((p: any) => (
          <Link
            key={p.id}
            href={`/projects/${p.id}`}
            className="block rounded px-3 py-2 text-sm hover:bg-gray-100"
          >
            {p.name || "Untitled Project"}
          </Link>
        ))}
      </div>
    )}
  </div>
  
)}
{/* TRASH */}
{deletedProjects.length > 0 && (
  <div className="mt-4">
    <Link
      href="/trash"
      className="flex items-center justify-between rounded px-3 py-2 text-sm text-red-600 hover:bg-red-50"
    >
      <span>Trash</span>
      <span className="text-xs font-semibold">
        {deletedProjects.length}
      </span>
    </Link>
  </div>
)}

    </nav>

    {/* LOG OUT (CANVA STYLE) */}
    <div className="px-4 py-4 border-t border-gray-200">
      <button
        onClick={handleLogout}
        className="w-full px-4 py-3 rounded-lg text-gray-700 font-medium text-base hover:bg-gray-100 transition"
      >
        Log Out
      </button>
    </div>
  </aside>
);


}
